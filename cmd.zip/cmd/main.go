package main

import "fmt"
import "github.com/abitofhelp/multimod/lib_a"

func main() {
	fmt.Println(lib_a.Howdy())
}
